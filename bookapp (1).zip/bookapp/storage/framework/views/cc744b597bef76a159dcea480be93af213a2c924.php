<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if(Session::has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('message')); ?>

                </div>

                <?php endif; ?>
                <div class="card mt-5">
                    <div class="card-header">Create a new Book</div>
                    <div class="card-body">
                        <form action="<?php echo e(route('book.store')); ?>" method="post" enctype="multipart/form-data" ><?php echo csrf_field(); ?>

                            <label>Name of book</label>
                            <input type="text" name="name" class="form-control" placeholder="name of book">
                            <?php if($errors->has('name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                            <?php endif; ?>
                            <br>
                            <label>Description of book</label>
                            <textarea name="description" class="form-control"></textarea>
                              <?php if($errors->has('description')): ?>
                                <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                            <?php endif; ?>
                            <br>
                            <label>Category</label>
                            <select name="category" class="form-control">
                                <option value="">select</option>
                                <option value="frictional">Frictional Book</option>
                                <option value="biography">Biography Book</option>
                                <option value="comdey">Comdey Book</option>
                                <option value="educational">Education</option>
                            </select>
                            <?php if($errors->has('category')): ?>
                            <span class="text-danger"><?php echo e($errors->first('category')); ?></span>
                        <?php endif; ?>
                        <label>Image of book</label>
                            <input type="file" name="image" class="form-control">
                              <?php if($errors->has('image')): ?>
                                <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                            <?php endif; ?>
                            <br>

                            <br>
                            <input type="submit" value="submit" class="btn btn-primary">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/bookapp/resources/views/book/create.blade.php ENDPATH**/ ?>