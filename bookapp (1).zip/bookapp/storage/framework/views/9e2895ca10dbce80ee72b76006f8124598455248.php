<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('message')); ?>

                    </div>

                <?php endif; ?>
                <div class="card mt-5">
                    <div class="card-header">List of all Books</div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Image</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Category</th>
                                    <th scope="col">Edit</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <?php if($book->image): ?>

                                        <img src="<?php echo e(Storage::url($book->image)); ?>" width="80">
                                            <?php else: ?> 
                                            <img src="/img/test.png" width="80">
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($book->name); ?></td>
                                        <td><?php echo e($book->description); ?></td>
                                        <td><?php echo e($book->category); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('book.edit', $book->id)); ?>">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('book.destroy', $book->id)); ?>" method="post"><?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <td>No any books</td>
                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
                <?php echo e($books->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/bookapp/resources/views/book/index.blade.php ENDPATH**/ ?>